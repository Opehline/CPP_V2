#ifndef HUND_H
#define HUND_H
namespace Hund
{
	void IchLebe();

		namespace HundUndKatze
		{
			class DasLeben
			{
				public:
					void NichtImmerSchoen();
			};
		}
}
#endif
