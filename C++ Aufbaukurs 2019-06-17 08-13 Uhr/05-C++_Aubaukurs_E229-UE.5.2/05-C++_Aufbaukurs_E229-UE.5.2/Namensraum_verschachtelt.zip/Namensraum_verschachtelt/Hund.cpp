#include <iostream>
#include "Hund.hpp"

void Hund::IchLebe()
{
	std::cout << "Ich atme...!" << std::endl;
	std::cout << "Ich esse...!" << std::endl;
	std::cout << "Ich schlafe...!" << std::endl;
	std::cout << "Ich belle...!" << std::endl;
	std::cout << "Und vieles mehr...!" << std::endl;
}
void Hund::HundUndKatze::DasLeben::NichtImmerSchoen()
{
	std::cout 
		<< "Das Leben waere super "
		<< "geabe es diese Katzen"
		<< "nicht...!" << std::endl;
}
