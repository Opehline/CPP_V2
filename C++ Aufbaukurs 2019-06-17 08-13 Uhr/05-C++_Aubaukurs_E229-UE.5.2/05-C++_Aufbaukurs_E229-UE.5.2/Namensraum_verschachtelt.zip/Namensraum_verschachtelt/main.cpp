#include <iostream>
#include "Hund.hpp"
#include "Katze.hpp"

/*
	using namespace Hund;
	//using namespace Hund::HundUndKatze;
	using namespace Katze;
	//using namespace Katze::KatzeUndHund;
*/

int main(int argc, char** argv) 
{
	#if 0
	//IchLebe();
	//Katze::IchLebe();
	// * Wenn eine Klasse einem Namensraum zugrundeliegt
	/*Hund::HundUndKatze::*/DasLeben Fifo;
	Fifo.NichtImmerSchoen();
	
	// * Ein und auskommentieren:
	Katze::KatzeUndHund::NichtImmerSchoen();
	//NichtImmerSchoen();
	#endif
	

	// * Geht nicht!
	IchLebe();
	IchLebe();
/*	NichtImmerSchoen();
	NichtImmerSchoen();
*/
	return 0;
}
