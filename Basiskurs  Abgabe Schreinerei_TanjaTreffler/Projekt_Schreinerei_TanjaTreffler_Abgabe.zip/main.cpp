// Tanja Treffler
//   Projekt f�r C++ Basiskurs
//   Schreinerei vereinfacht abbilden

#include <iostream>

#include "begruessungsfunktionen.hpp"

using namespace std;

int main()
{
    startBetrieb();

    return 0;
}
