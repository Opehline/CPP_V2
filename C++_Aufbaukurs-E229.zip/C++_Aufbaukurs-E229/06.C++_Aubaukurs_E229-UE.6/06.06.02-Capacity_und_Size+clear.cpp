// Gisela Neira
// C++ Aufbaukurs E229
// * Programm 06.06.02 der C++ Programmierung
// * Unterscheidung zwischen size() und capacity()

#include <iostream>
#include <iomanip>
#include <vector>

int main()
{
    std::vector<int> mein_vector;
    int* p_vector = NULL;
    for(int i=0; i<=20; i++)
    {
        mein_vector.push_back(i);
        std::cout << "mein_vector.size() "
                  << mein_vector.size() << std::endl;
        std::cout << "mein_vector.capacity() "
                  << mein_vector.capacity() << std::endl;
        std::cout << "mein_vector.at(i) "
                  << mein_vector.at(i) << std::endl;


        std::cout << &mein_vector[0] << std::endl;

        if(i==0)
        {
            //p_vector=&mein_vector[0];
        }
    }
    p_vector=&mein_vector[0];
    std::cout << "p_vector> " << p_vector << std::endl;

    for(int i=0; i<=20; i++)
    {
        std::cout << mein_vector.at(i) << std::endl;
        std::cout << *(p_vector+i) << std::endl;
    }

return 0;

}
