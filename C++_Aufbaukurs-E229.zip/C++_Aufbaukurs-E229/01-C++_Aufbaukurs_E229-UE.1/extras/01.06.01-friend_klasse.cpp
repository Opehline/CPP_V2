// Gisela Neira
// C++ Aufbaukurs E229
// * Programm 01.06.01 der C++ Programmierung
// * friend-Klasse
#include <iostream>
#include <string>

class Jemand
{
    private:
      std::string hallo;

      friend class DerFreund;
};

class DerFreund
{
    private:
      int mengeGruesse;
      Jemand nachbar;
    public:
        // * Funktion
        std::string gruss();
        void set_mengeGruesse_und_Hallo(int, std::string);
};

std::string DerFreund::gruss()
{
    std::cout << nachbar.hallo << std::endl;
}

void DerFreund::set_mengeGruesse_und_Hallo(int _mengeGruesse, std::string _hallo)
{
    mengeGruesse=_mengeGruesse;
    nachbar.hallo=_hallo;
}

int main(void)
{
    DerFreund Tom;
    Tom.set_mengeGruesse_und_Hallo(5, "Wie schoen Dich wiederzusehen!");
    Tom.gruss();

}
