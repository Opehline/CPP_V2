// Gisela Neira
// C++ Aufbaukurs E229
// * Programm 01.06.01 der C++ Programmierung
// * friend-Funktion
#include <iostream>
#include <string>

class Jemand;
class DerFreund
{
    private:
      int mengeGruesse;
      //Jemand& nachbar; // * Fehler in Zeile 16
      Jemand* nachbar;

    public:
        DerFreund(){mengeGruesse=0;}
        // * Funktion
        std::string gruss();
        void set_mengeGruesse_und_Hallo(int, std::string);
};





