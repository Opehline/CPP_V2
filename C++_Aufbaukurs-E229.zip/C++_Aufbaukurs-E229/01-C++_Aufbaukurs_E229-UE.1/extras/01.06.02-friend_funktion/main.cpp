#include <iostream>
#include "DerFreund.hpp"
#include "Jemand.hpp"


std::string DerFreund::gruss()
{
    std::cout << nachbar->hallo << std::endl;
}

void DerFreund::set_mengeGruesse_und_Hallo(int _mengeGruesse, std::string _hallo)
{
    mengeGruesse=_mengeGruesse;
    //nachbar->hallo=_hallo;
}

int main(void)
{
    DerFreund Tom;
    Tom.set_mengeGruesse_und_Hallo(5, "Wie schoen Dich wiederzusehen!");
    Tom.gruss();
return 0;
}
