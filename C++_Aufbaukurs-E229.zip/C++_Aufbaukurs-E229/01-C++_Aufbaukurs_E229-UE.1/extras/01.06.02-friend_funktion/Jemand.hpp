#include <iostream>
#include <string>

//class DerFreund;
class Jemand
{
    private:
      std::string hallo;
      friend std::string DerFreund::gruss();

    public:
        Jemand(){hallo="";}
};
