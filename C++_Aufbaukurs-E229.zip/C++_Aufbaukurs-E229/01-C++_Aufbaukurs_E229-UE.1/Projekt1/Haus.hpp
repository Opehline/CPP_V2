// Gisela Neira
// C++ Aufbaukurs E229
// * Programm 01.06.01 der C++ Programmierung
// * Projekt einer Klasse erstellen

#include "Punkt.hpp"

class Haus
{
    public:
        Punkt einPunkt;
        void funk();
};
