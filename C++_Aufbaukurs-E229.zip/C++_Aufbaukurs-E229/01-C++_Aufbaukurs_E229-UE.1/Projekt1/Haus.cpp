#include "Haus.hpp"
#include <iostream>

void Haus::funk()
{
    std::cout << "Hallo Welt" << std::endl;
}
