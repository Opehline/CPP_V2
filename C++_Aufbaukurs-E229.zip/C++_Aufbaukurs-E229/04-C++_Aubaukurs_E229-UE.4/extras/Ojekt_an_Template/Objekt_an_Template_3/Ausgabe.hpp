#include <iostream>

#ifndef _AUSGABE_
#define _AUSGABE_
class Ausgabe
{
	public:

	template<typename KlasseObject> 
	void ausgabef(KlasseObject&);
};
#endif
