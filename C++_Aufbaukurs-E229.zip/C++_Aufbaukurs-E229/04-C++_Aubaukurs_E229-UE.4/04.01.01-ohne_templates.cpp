// Gisela Neira
// C++ Aufbaukurs E229
// * Programm 04.01.01 der C++ Programmierung
// * Programm ohne Template

#include <iostream>
#include <array>


// * Es soll das Resultat erreichnet werden, mit nur int-Werten.
float rechnen(float x, int y, int z)
{
    float result;

    result = ((x*x)-y)/z;
    return result;
}

// * Bei Variablentypaenderung:
// * Fuer jeden neuen Fall ist es notwendig neu die Funktion zu erstellen.

int main()
{
    float a = 4.675;
	int b = 5;
	int c = 2;
	double r;

    r = rechnen(a, b, c);

    std::cout << "\n"<< r << "\n" << std::endl;

    return 0;
}
