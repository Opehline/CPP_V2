#include <iostream>
#include <iomanip>

int main(void)
{
    std::cout << std::setw(5);
    std::cout << 1 << std::endl;
return 0;
}
