// Gisela Neira
// C++ Basics E228
// * Programm 06.01.06 der C/C++ Programmierung
// * Stuctuebergabe an eine Funktion
// * Ausgabe auf Bildschirm

#include <iostream>

struct specStruct
{
	int count;
	int member[100];
}sMember;

class specClass
{
	int count;
	int member[100];
	public:
		// * Methoden werden physich nicht innerhalb der Klasse im Speicher gelegt.
		int machwas(){ std::cout << "Mach was" << std::endl;}
}cMember;


// * Alle drei Schittstellen sind richtig:
int fausgabe(struct specStruct liste) 	// * Uebergabe als Kopie (Call by Value) mit Zeile 35
//int fausgabe(struct specStruct &liste)	// * Uebergabe als Referenz (in C++ Form) mit Zeile 35
//int fausgabe(struct specStruct *liste)  // * Uebergabe der Adresse an Pointer mit Zeile 38
{
	std::cout << "Tus was" << std::endl;
}

int main(int argc, char **argv)
{
    fausgabe(sMember); 			// * richtig: 	Uebergabe als Kopie aber auch als Referenz
								// * 			(da Name auch auf das erste Element der Struktur referenziert.)
    //fausgabe(*sMember); 		// * falsch: 	hier wird versucht einen leeren Pointer zu uebergeben
    //fausgabe(&sMember); 		// * richtig: 	uebergabe der Adresse der Struktur (Uebergabe durch Pointer)


	#if 0
    int wahr1 = sizeof(specClass)==sizeof(specStruct);
    int wahr2 = sizeof(cMember)==sizeof(sMember);
    std::cout << wahr1 << std::endl;
    std::cout << wahr2 << std::endl;
	#endif

return 0;
}
