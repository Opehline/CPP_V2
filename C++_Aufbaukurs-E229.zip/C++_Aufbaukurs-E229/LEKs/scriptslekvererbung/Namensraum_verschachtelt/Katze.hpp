#ifndef KATZE_H
#define KATZE_H
namespace Katze
{
	void IchLebe();
	void wasAnderes();

	namespace KatzeUndHund
	{
		//float a; 	// * Lose Variable nicht moeglich.
		void NichtImmerSchoen();
	}
}
#endif
