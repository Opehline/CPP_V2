#include <iostream>
#include "Katze.hpp"

void Katze::wasAnderes()
{
    ;
}

void Katze::IchLebe()
{
	std::cout
		<< "Leben ist etwas sehr"
		<< "schoenes... Miauuuuu!"
		<< "Ich liebe es mich sauber zu halten!"
		<< std::endl;
}

void Katze::KatzeUndHund::NichtImmerSchoen()
{
	std::cout
		<< "Ojeeeeee......"
		<< "ein...."
		<< "Hund!" << std::endl;
}
