// Gisela Neira
// C++ Aufbaukurs E229
// * LEK Vorbereitung
// * Vererbung: mehrfach Vererbung
// * Gleichnamige Member
// * Kein Diamantenproblem: hier hilft "virtual" nicht

#include <iostream>

using namespace std;

class Vater
{
    protected:
		std::string name;
		void gleichnamigeFunk()
		{
			;
		}
};

class Mutter
{
    protected:
		std::string name;
		void gleichnamigeFunk()
		{
			;
		}
};

class Tochter : public Mutter, public Vater //: virtual public Vater, virtual public Mutter
{
    private:

    protected:

    public:
		void setName(std::string x)
		{
            name = x;
			cout << name;
		}
		void gleichnamigeFunk()
		{
			;
		}

};

int main(int argc, char **argv){

    Tochter momi;
	momi.setName("Kuki");

return 0;
}
