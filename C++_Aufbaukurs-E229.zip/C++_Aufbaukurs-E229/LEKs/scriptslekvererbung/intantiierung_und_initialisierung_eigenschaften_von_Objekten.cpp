// Gisela Neira
// C++ Aufbaukurs E229
// * LEK Vorbereitung
// * Initialisierungsformen von private Variablen
// * Alle drei Formen instantieren unser Objekt

#include <iostream>

class Vater
{
    private:
		int x, y, z;
	public:
	    #if 1
		Vater(int a, int b, int c) : x(a), y(b), z(c) 	// * Konstruktor
		{
			std::cout << x << " " << y << " " << z << "\n";
		}
		#endif
		/*
		Vater(int a, int b, int c) // * Konstruktor
		{
			x=0;
			y=0;
			z=0;
		}
		*/
		#if 1
		Vater(const Vater& c): x(c.x), y(c.y), z(c.z) 	// * Kopierkonstruktor
		{
			std::cout << x << " " << y << " " << z << "\n";
		}
		#endif // 0
		~Vater()
		{}
};

int main(int argc, char **argv)
{
	std::cout << "Pepu ";
	Vater pepu(3, 5, 9);
	std::cout << "Clon ";
	Vater clon(pepu);
	std::cout << "Kolu ";
	Vater kolu={0x00, 0x80, 0xc0}; // * 0, 128, 192

return 0;
}
