// Gisela Neira
// C++ Aufbaukurs E229
// * LEK Vorbereitung
// * Vererbung von Funktion die Operator =
// * ueberlaedt?

#include <iostream>
#include <cstring>

#define OPERATORFunc

class TextVerwaltung
{
	protected:
		int laenge;
		char *einText;

	public:
		TextVerwaltung(){};
		TextVerwaltung(char *t);
		TextVerwaltung(const TextVerwaltung& c); // * Copy-Konstruktor
		~TextVerwaltung();
		void Ausgabe();
		#ifdef OPERATORFunc
		// * Ueberladen von Operator =
		TextVerwaltung& operator=(TextVerwaltung& ub); // * Ueberladen von den Zuweisungsoperator (=)
		#endif
};

class Kind : public TextVerwaltung{}; NEIN

void TextVerwaltung::Ausgabe()
{
	std::cout << einText << std::endl;
}

TextVerwaltung::TextVerwaltung(char *t)
{
	laenge = (int)strlen(t);
	einText = (char *) malloc(laenge+1);
	strcpy(einText, t);
}

TextVerwaltung::TextVerwaltung(const TextVerwaltung& c)
{
	laenge = c.laenge;
	einText = (char *) malloc(laenge+1);
	strcpy(einText, c.einText);
}

#ifdef OPERATORFunc
TextVerwaltung& TextVerwaltung::operator=(TextVerwaltung &ub)
{
	free(einText);
	// * Auf moegliche Selbstzuweisung ueberpruefen
	// * Eine moegliche Selbstzuweisung des Objekts auf sich
	// * selber soll vermieden werden.

	if(&ub==this)
	{
		std::cout << "Selbszuweisung" << std::endl;
		return *this;
	}

	laenge = ub.laenge;
	einText = (char *) malloc(laenge+1);
	strcpy(einText, ub.einText);
	return *this;
}
#endif

TextVerwaltung::~TextVerwaltung()
{
	free(einText);
	std::cout << "Heapspeicher wurde befreit..!" << std::endl;
}

class EineAndereKlasse : public TextVerwaltung
{
	public:
		EineAndereKlasse(char *t);
		EineAndereKlasse(const EineAndereKlasse& c);
};

EineAndereKlasse::EineAndereKlasse(char *t)
{
	laenge = (int)strlen(t);
	einText = (char *) malloc(laenge+1);
	strcpy(einText, t);
}

EineAndereKlasse::EineAndereKlasse(const EineAndereKlasse& c)
{
	laenge = c.laenge;
	einText = (char *) malloc(laenge+1);
	strcpy(einText, c.einText);
}

int main()
{
	EineAndereKlasse tv1("Ein sowas von toller Text!");
	EineAndereKlasse tv2("Ein langweiliger Text... gaehhhhnnn....");

	// * Wir wollen es aber spannend haben.
	tv2 = tv1;
	tv2.Ausgabe();

return 0;
}
