// Gisela Neira
// C++ Aufbaukurs E229
// * LEK Vorbereitung
// * const-Funktionen C++
// * Merksatz: 	In C++ koennen konstante Funktionen
// * 			NUR konstante Funktionen aufrufen.

#include <iostream>
#include <string>

using namespace std;

class Vater
{
    private:
		char Geschlecht; 		// * m=maenlich, w=weiblich, u=undefiniert
		int Alter;
		string Name;

		void funktion_sprachenvater() /*const*/;
		void funktion_Geschlecht(char Geschlecht) const;
		void funktion_Name(string Name) const;
		int funktion_Alter(int Alter) const;

   	public:
		Vater(){};

		void funktion_DatenAusgeben(char _geschlecht, int _alter, string _name) const;
};


void Vater::funktion_sprachenvater() /*const*/
{
	cout << "Ich kann englisch." << endl;
	cout << "Ich kann deutsch." << endl;
	cout << "Ich kann italienisch." << endl;
}

void Vater::funktion_Geschlecht(char Geschlecht) const
{
	cout << "Geschlecht: " << Geschlecht << endl;
}

void Vater::funktion_Name(string Name) const
{
	cout << "Name: " << Name << endl;
}

int Vater::funktion_Alter(int Alter) const
{
	cout << "Alter: " << Alter << endl;
	return Alter;
}

void Vater::funktion_DatenAusgeben(char _geschlecht, int _alter, string _name) const
{
	funktion_sprachenvater();
	funktion_Geschlecht(_geschlecht);
	funktion_Name(_name);
	funktion_Alter(_alter);
	cout << "Ich werde in drei Jahren " << Alter+3 << " Jahre alt sein." << endl;
}


int main(int argc, char **argv){

	Vater vater;
	vater.funktion_DatenAusgeben('m', 56, "Holzhauer");

return 0;
}
