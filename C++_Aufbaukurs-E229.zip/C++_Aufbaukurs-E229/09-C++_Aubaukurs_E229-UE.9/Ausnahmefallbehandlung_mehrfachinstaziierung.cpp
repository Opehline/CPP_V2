// Gisela Neira
// C++ Aufbaukurs E229
// * Ausnahmefallbehandlug 03.03.02 der C++ Programmierung
//   try-catch-Anweisungen erweitert

#include <iostream>

#define AUSNAHME_A 1

class Ausnahmefallbehandlung //: exception
{
	private:
		int grund;
	public:
		Ausnahmefallbehandlung(int _grund);
};


Ausnahmefallbehandlung::Ausnahmefallbehandlung(int _grund)
{
    std::cout << "Konstruktor > " << this << std::endl;
};

void wertEingeben();



int main()
{
	try
	{
		wertEingeben();
	}
	catch(Ausnahmefallbehandlung a)
	{
	    std::cout << "main > " << &a << std::endl;
	}

return 0;
}

void wertEingeben()
{
	int val=0;

	std::cout <<"\nWert eingeben: ";
	std::cin>>val;

	if(std::cin.fail())
	{
		throw Ausnahmefallbehandlung(AUSNAHME_A);	// * Selbstdefinierter Rueckgabewert
	}
}
