// Gisela Neira
// C++ Aufbaukurs E229
// * Programm 0x.0x.01 der C++ Programmierung
// * Pointer auf Objekte

#include <stdio.h>
#include <iostream>


double einFunktion(int x, char m)
{
    return x;
}

double andereFunktion(double(* pf)(int, char))
{
	printf("Hier wird eine Funktion zurueckgegeben > ");
	///....
	///.....
	return (pf)(5, '*'); // * Die zurueckgeworfene Funktion
						 // * muss auch returnen.
}

int main()
{
    double(* p_Funk)(int, char)/*= &einFunktion*/;
    p_Funk = &einFunktion;

    printf("Speicheradresse der Funktion > %#p\n", p_Funk);

	std::cout << andereFunktion(p_Funk);

return (p_Funk)(5, '=');
}
