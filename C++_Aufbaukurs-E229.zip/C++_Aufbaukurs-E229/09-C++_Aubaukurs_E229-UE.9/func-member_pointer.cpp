// Gisela Neira
// C++ Aufbaukurs E229
// * Programm 0x.0x.02 der C++ Programmierung
// * Pointer auf Objekte

#include <iostream>
#include <stdlib.h>

class BasisKlasse
{
	public:
	    BasisKlasse();
		double classFunk(double);
		BasisKlasse& operator=(BasisKlasse&);
};

class KindKlasse :
    public BasisKlasse
{
	;
};

// * MEMBER FUNKTIONEN
BasisKlasse::BasisKlasse()
{
    ;
}
double BasisKlasse::
    classFunk(double x)
{;}

BasisKlasse& BasisKlasse::
    operator=(BasisKlasse& op)
{
    std::cout << this << "\n";}


int main()
{
    KindKlasse ob2, ob3;
	ob3=ob2;
	std::cout << &ob3 << " " << &ob2 << "\n";

    printf("Member Funktion > %#p\n", &BasisKlasse::classFunk);
	printf("Member Funktion > %#p\n", &KindKlasse ::classFunk);;
    return 0;
}
