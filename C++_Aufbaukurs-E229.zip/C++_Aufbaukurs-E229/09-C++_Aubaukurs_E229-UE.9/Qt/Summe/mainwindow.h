#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QPushButton>
#include <QObject>
#include <QtGui>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT // * Macro das angibt: diese Klasse beinhaltet gui-Elemente
             // * und muss durch den meta object compiler abgelaufen werden.
             // * Dieses Macro ist insbesondere notwendig fals signal and
             // * slots gebraucht werden.

    public:
        explicit MainWindow(QWidget *parent = nullptr);
        ~MainWindow();
        QPushButton* m_pButton;

    public slots:
       void on_btnAdd_clicked();

    private:
        Ui::MainWindow* ui;
        int a;
        int b;
        int result;
};


#endif // MAINWINDOW_H
