#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QCoreApplication>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->pushButton->setText("Tschüss!");

    //Knopf wird erstellt
    m_pButton = new QPushButton("Was kommt raus?");
}

MainWindow::~MainWindow()
{
    delete ui;
    delete m_pButton;
}

void MainWindow::on_btnAdd_clicked()
{
    int a = ui->lineEdit_1->text().toInt();
    int b = ui->lineEdit_2->text().toInt();
    int result = a+b;
    ui->lineEdit_3->setText(QString::number(result));
}
