#include "mainwindow.h"
#include <QApplication>
#include <QTextEdit>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;

    //Groesse, form un position des Konpfes
    //m_pButton->setGeometry(QRect( QPoint(200, 100),QSize(100, 50)));
    w.m_pButton->setGeometry(300, 300, 200, 80);
    QObject::connect(w.m_pButton, SIGNAL (clicked()), &w, SLOT(on_btnAdd_clicked()));

    w.m_pButton->show();
    w.show();

    return a.exec();
}
