#include <QCoreApplication>
#include <QDebug>
#include <iostream>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    qDebug() << "Hallo Teilnehmer, fast geschafft!";
    std::cout << "Hallo Leute!" << std::endl;
    printf("Reines C!");

    return a.exec();
}
