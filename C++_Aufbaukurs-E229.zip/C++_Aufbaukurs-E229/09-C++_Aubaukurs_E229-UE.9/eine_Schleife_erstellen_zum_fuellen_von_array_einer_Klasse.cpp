#include <iostream>

#define FUNK_FUELLEN
#define DEFAULT_KONSTRUKTOR

class Spielfigur
{
	protected:	
		int xPos;
		int yPos; 
		
	public:		
		#ifdef DEFAULT_KONSTRUKTOR
		Spielfigur(){}
		#endif
		Spielfigur(int xStart, int yStart) 
		{
			xPos = xStart;
			yPos = yStart;
			std::cout << "Ausgabe class Spielfiegur   > " << xPos << " " << yPos << std::endl;
			//std::cout << "Ausgabe class Spielfiegur   > " << xStart << " " << yStart << std::endl;
		}
		char name;	
};

class Feld : public Spielfigur
{
	private:
		int xStart, yStart;
	public:
		
		
		#ifdef DEFAULT_KONSTRUKTOR
		Feld(){}
		#endif
		
		Feld(int xStart, int yStart) : Spielfigur(xStart, yStart)
		{
			//std::cout << "Ausgabe class Feld   > " << xStart << " " << yStart << std::endl;
		}
		
		int getxStart()
		{
			return xPos;
		}
		
		int getyStart()
		{
			return yPos;
		}
};
/*
class Brett
{
	public:

		Brett(){}
		#ifndef FUNK_FUELLEN
		Feld mSpielfeld[8][8] = 
		{							
			{ Feld(0, 0), Feld(0, 1), Feld(0, 2), Feld(0, 3),Feld(0, 4), Feld(0, 5), Feld(0, 6), Feld(0, 7) },
			{ Feld(1, 0), Feld(1, 1), Feld(1, 2), Feld(1, 3),Feld(1, 4), Feld(1, 5), Feld(1, 6), Feld(1, 7) },
			{ Feld(2, 0), Feld(2, 1), Feld(2, 2), Feld(2, 3),Feld(2, 4), Feld(2, 5), Feld(2, 6), Feld(2, 7) },
			{ Feld(3, 0), Feld(3, 1), Feld(3, 2), Feld(3, 3),Feld(3, 4), Feld(3, 5), Feld(3, 6), Feld(3, 7) },
			{ Feld(4, 0), Feld(4, 1), Feld(4, 2), Feld(4, 3),Feld(4, 4), Feld(4, 5), Feld(4, 6), Feld(4, 7) },
			{ Feld(5, 0), Feld(5, 1), Feld(5, 2), Feld(5, 3),Feld(5, 4), Feld(5, 5), Feld(5, 6), Feld(5, 7) },
			{ Feld(6, 0), Feld(6, 1), Feld(6, 2), Feld(6, 3),Feld(6, 4), Feld(6, 5), Feld(6, 6), Feld(6, 7) },
			{ Feld(7, 0), Feld(7, 1), Feld(7, 2), Feld(7, 3),Feld(7, 4), Feld(7, 5), Feld(7, 6), Feld(7, 7) }
		};

		#else		
		Feld mSpielfeld[8][8];
		Feld f_mSielfeld()
		{
			int i=0, a=0;
			
			for(a=0; a<=7; a++)
			{
				for(i=0; i<=7; i++)
				{
					Feld meinFeld(a,i); 		// * Feld(int xStart, int yStart)
					mSpielfeld[a][meinFeld.getxStart(), meinFeld.getyStart()];
				}
			}
		}
		#endif
};
*/
int main()
{
	Feld feld(3,2);
	
	return 0;
}
