#include "Automaten.hpp"

void Automaten::Ausgabe()
{std::cout << "Was bin ich fuer ein Automat? Soll ich Getraenke servieren "
           << "oder Geld ausspucken??" << std::endl;}

void Automaten::vieleAusgaben()
{Ausgabe();}

Geldautomaten::Geldautomaten()
{
    std::cout << "Neuer Geldautomat ist erstellt!"
              << std::endl;
}

Geldautomaten::~Geldautomaten(){}

void Geldautomaten::Ausgabe()
{std::cout << "Ich schlucke Geld, gebe aber keins raus!" << std::endl;}
void Geldautomaten::wasTun()
{std::cout << "Huch?" << std::endl;}
