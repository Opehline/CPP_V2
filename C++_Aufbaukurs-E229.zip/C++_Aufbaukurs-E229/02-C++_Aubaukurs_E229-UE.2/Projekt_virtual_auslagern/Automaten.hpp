#include <iostream>
class Automaten
{
    private:
	protected:
		int BildschirmMenge;

	public:
	    void vieleAusgaben();
        virtual void Ausgabe();
};

class Geldautomaten : public Automaten
{
	public:
		// * Konstruktor
		Geldautomaten();
		~Geldautomaten();

    private:
        void Ausgabe() override;
        void wasTun();
};

