#include <iostream>
#include "Automaten.hpp"

int main()
{
    std::cout << "Geldautomat b11" << std::endl;
    Geldautomaten b11;
    b11.vieleAusgaben();

    return 0;
}
