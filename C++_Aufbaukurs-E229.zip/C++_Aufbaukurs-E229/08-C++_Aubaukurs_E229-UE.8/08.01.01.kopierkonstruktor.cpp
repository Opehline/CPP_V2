// Gisela Neira
// C++ Aufbaukurs E229
// * Programm 09.01.01 der C++ Programmierung
// * Kopierkonstruktor
// * Uebergabe Objekt als Parameter zur Erstellung
// * des neuen Objekts

#include <iostream>
#include <string>

class Schaf
{
    public:
	    int alter;
	    std::string name;

	    Schaf()
	    {
			alter = 0;
			name = "\0";
			std::cout << "Bin ein Schaf." << std::endl;
	    }
};

int main()
{
    Schaf dolly;						// * Wird nur einmal aufgerufen
    dolly.alter=15;
    dolly.name="Dolly";
    std::cout << "\nSchaf sagt: " << std::endl;
    std::cout << dolly.alter << std::endl;
    std::cout << dolly.name<< std::endl;

    Schaf dolly_clon(dolly);			// * Das ist ein "Kopierkonstruktor"
    std::cout << "\nKopierter Schaf sagt: " << std::endl;
    std::cout << dolly_clon.alter << std::endl;
    std::cout << dolly_clon.name<< std::endl;

return 0;
}
