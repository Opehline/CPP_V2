// Gisela Neira
// C++ Aufbaukurs E229
// * Ausnahmefallbehandlug 03.01.05 der C++ Programmierung
// * Werfen eines Objekts

#include <iostream>

class Daten
{
    private:
        int eingabe;
        std::string name;

	public:
	    // * Konstruktors
	    Daten(){eingabe=0; name="";}
        // * Setters
	    void setName(std::string _name)
	    {name=_name;}
	    void setEingabe(int _eingabe)
	    {eingabe=_eingabe;}
	    // * Funktionen
        void Ausgabe()
		{
			std::cout << "Benutzer > " << name
                      << " hat einen Wert eingegeben"<< std::endl;
		}
};

int main()
{
	int eingabe=0;
	std::string BenutzerName="";
	Daten benutzerHeinz;

    std::cout << "Benutzername eingeben: >";
    std::cin>> BenutzerName;
    benutzerHeinz.setName(BenutzerName);
    std::cout << "Benutzercode eingeben: >";
    std::cin.ignore();

		try
		{
			std::cin>>eingabe;

			if(std::cin.fail())
			{
				std::cin.clear();
				std::cout<<"\n*****AUSNAHMEFALL WURDE HERVORGERUFEN!****\n"
                         << std::endl;
                // * Es wird ein Objekt als Referenz geworfen
				throw benutzerHeinz;
				//throw &benutzerHeinz;
			}
			else
			{
				std::cout << "Eingebe erfolgreich." << std::endl;
				benutzerHeinz.setEingabe(eingabe);
			}
		}
		//catch(Daten value)
		catch(Daten& value)			// * Referenz des Objekts wird "gecatcht"
		//catch(Daten *value)
		{
			value.Ausgabe();
			//value->Ausgabe(&name);
		}

return 0;
}
