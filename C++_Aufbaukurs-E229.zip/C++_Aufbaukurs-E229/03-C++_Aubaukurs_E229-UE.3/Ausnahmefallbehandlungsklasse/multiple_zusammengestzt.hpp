#include <iostream>
#include <exception> //Bibliothek muss ergänzt werden

void alterEingeben();
void wertEingeben();
